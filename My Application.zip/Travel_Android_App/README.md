# Travel_Android_App

>>>>Still in progress<<<<

It's kind of travel application. It's dedicated mainly for students from outside the Poland to help them moving around
the Szczecin city. It shows where they can eat, sleep, have fun etc. There is also google map added with searching option
for nearby points which depends on chosen category. 

 >November
- Exit from the application after double "back" button press.
- Blocked moving Mainmenu -> Login Screen (by "back" button)
- Blocked moving from logout back to the application
- Added transfer back from ListViews to Mainmenu (not to previous Activity)
- Added "About me" activity
- Added logout from the application
- Added contact option
- Changed names of the categories
- Repaired image scaling in the toolbar
- Changed img behaviour after choosing the category (added shadow, changed size on click)

12.11.2019
- Added self location
- Added google map and connection to it
- Added searching for nearby places by category
- Added new layouts and icons to maps
- Added place search in the searchbar
- Added button with self location
- Added option to show place on the map
- Simplify the code from 12 Activities to 2 
- Added redirection to html site from "Events" option
- Added new options in main menu and on searchbar
- Added new places to database
